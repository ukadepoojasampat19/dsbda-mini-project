from flask import Flask, render_template, request
import numpy as np
import joblib
import pickle

# Load the trained model
gnb = joblib.load('case_study_2.pkl')

# Set up the Flask app
app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get feature values from the user
        distance_from_home = float(request.form['distance_from_home'])
        distance_from_last_transaction = float(request.form['distance_from_last_transaction'])
        ratio_to_median_purchase_price = float(request.form['ratio_to_median_purchase_price'])
        repeat_retailer = int(request.form['repeat_retailer'])
        used_chip = int(request.form['used_chip'])
        used_pin_number = int(request.form['used_pin_number'])
        online_order = int(request.form['online_order'])

        # Make predictions on the new transaction
        new_transaction = [
            [distance_from_home, distance_from_last_transaction, ratio_to_median_purchase_price, repeat_retailer,
             used_chip, used_pin_number, online_order]]
        prob_fraud = gnb.predict_proba(new_transaction)[0][1]

        # Set a threshold for fraud detection
        threshold = 0.5

        # Print the predicted label
        if prob_fraud > threshold:
            predicted_label = 'Fraudulent transaction detected.'
        else:
            predicted_label = 'Legitimate transaction.'

        # Render the template with the predicted label
        return render_template('flask.html', predicted_label=predicted_label)

    # Render the empty template for the first time
    return render_template('flask.html')


if __name__ == '__main__':
    app.run(debug=True)